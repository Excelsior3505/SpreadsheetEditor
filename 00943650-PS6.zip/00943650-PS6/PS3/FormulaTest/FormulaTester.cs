﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SpreadsheetUtilities;
using System.Collections.Generic;

namespace FormulaTester
{
    /// <summary>
    /// All tests for the formula class
    /// </summary>
    [TestClass]
    public class FomulaTests
    {
        //test if the constructor works and is the formula is sytactically correct
        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest()
        {
            Formula f = new Formula("-1");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest2()
        {
            Formula f = new Formula("2A");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest3()
        {
            Formula f = new Formula("2x+y3");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest5()
        {
            Formula f = new Formula(")1");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest6()
        {
            Formula f = new Formula("6(");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest5_1()
        {
            Formula f = new Formula("))1(");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest6_1()
        {
            Formula f = new Formula("6())");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest7()
        {
            Formula f = new Formula("6+");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest8()
        {
            Formula f = new Formula("-6");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest9()
        {
            Formula f = new Formula("");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest10()
        {
            Formula f = new Formula("8+7*(+");
        }

        [TestMethod]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SyntaxTest11()
        {
            Formula f = new Formula("1+2+(3+4))");
        }

        /// <summary>
        /// tests for evaluator
        /// </summary>
        [TestMethod]
        public void EvaluateTest()
        {
            Formula f = new Formula("1+2*x");
            double result = (double)f.Evaluate(s=>3);
            Assert.AreEqual(7,result);
        }

        //[TestMethod]
        //public void EvaluateTest2()
        //{
        //    Formula f = new Formula("1+a");
        //    Assert.IsInstanceOfType(f.Evaluate(s => { throw new 
        //        ArgumentException("unassigned variable"); }), typeof(FormulaError));
        //}

        [TestMethod]
        public void EvaluateTest3()
        {
            Formula f = new Formula("1/0");
            object result = f.Evaluate(s => 0);
            Assert.IsInstanceOfType(result, typeof(FormulaError));
        }




        /// <summary>
        /// Test for the GetVariablesTest()
        /// </summary>
        /// 
        [TestMethod]
        public void GetVariablesTest()
        {
            Formula f = new Formula("1+2*3");
            Assert.IsFalse(f.GetVariables().GetEnumerator().MoveNext());
        }

        [TestMethod]
        public void GetVariablesTest2()
        {
            Formula f = new Formula("1+2*n");
            Assert.IsTrue(f.GetVariables().GetEnumerator().MoveNext());
        }


        /// <summary>
        /// tests for Equals()
        /// </summary>
        [TestMethod]
        public void EqualTest()
        {
            Formula f = new Formula("x+y+z");
            Formula f2 = new Formula("x+y+z");
            Assert.IsTrue(f.Equals(f2));
        }

        [TestMethod]
        public void EqualTest2()
        {
            Formula f = new Formula("x + y + z");
            Formula f2 = new Formula("x+y+z");
            Assert.IsTrue(f.Equals(f2));
        }

        [TestMethod]
        public void EqualTest3()
        {
            Formula f = new Formula("X+Y+Z");
            Formula f2 = new Formula("x+y+z");
            Assert.IsFalse(f.Equals(f2));
        }

        [TestMethod]
        public void EqualTest4()
        {
            Formula f = new Formula("1+2*z");
            Formula f2 = new Formula("1+2*z");
            Assert.IsTrue(f.Equals(f2));
        }

        [TestMethod]
        public void EqualTest5()
        {
            Formula f = new Formula("      1   +    4      ");
            Formula f2 = new Formula("1+4");
            Assert.IsTrue(f.Equals(f2));
        }

        /// <summary>
        /// tests for ==(f1,f2)
        /// </summary>
        [TestMethod]
        public void IsEqualTest()
        {
            Formula f = new Formula("1+4");
            Formula f2 = new Formula("1+4");
            Assert.IsTrue(f == f2);
        }
        [TestMethod]
        public void IsEqualTest2()
        {
            Formula f = new Formula("1+4");
            Formula f2 = new Formula("1+4");
            Assert.IsFalse(null == f2);
            Assert.IsTrue(f == f2);
        }

        [TestMethod]
        public void IsEqualTest3()
        {
            Formula f = new Formula("n");
            Formula f2 = new Formula("n");
            Assert.IsFalse(f == null);
            Assert.IsFalse(f2 == null);
            Assert.IsTrue(null == null);
        }


        /// <summary>
        /// tests for !=(f1,f2)
        /// </summary>
        [TestMethod]
        public void IsNotEqualTest()
        {
            Formula f = new Formula("1+4");
            Formula f2 = new Formula("1-4");
            Assert.IsTrue(f != f2);
        }

        [TestMethod]
        public void IsNotEqualTest2()
        {
            Formula f = new Formula("1+4");
            Formula f2 = new Formula("1+4");
            Assert.IsFalse(f != f2);
        }

        [TestMethod]
        public void IsNotEqualTest3()
        {
            Formula f = new Formula("1+4");
            Formula f2 = new Formula("1+4");
            Assert.IsTrue(f != null);
            Assert.IsTrue(f2 != null);
            Assert.IsFalse(null != null);
        }

    }


}
