﻿// Skeleton implementation written by Joe Zachary for CS 3500, September 2013.
// Version 1.1 (Fixed error in comment for RemoveDependency.)

///-----------------------------------------------------------------
///   Namespace:      <Class Namespace> SpreadsheetUtilities
///   Class:          <Class Name> DependencyGraph
///   Description:    <Description> SpredSheet Class library contains DependencyGraph
///   Author:         <Author> Joe Zachary(skeleton builder), Sharon Xiao(u0943650)      
///   Date Comented:  <DateTime> 9/13/2016
///   Notes:          <Notes> An class library of SpreadsheetUtilities, not an excuteable
///-----------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpreadsheetUtilities
{

    /// <summary>
    /// (s1,t1) is an ordered pair of strings
    /// t1 depends on s1; s1 must be evaluated before t1
    /// 
    /// A DependencyGraph can be modeled as a set of ordered pairs of strings.  Two ordered pairs
    /// (s1,t1) and (s2,t2) are considered equal if and only if s1 equals s2 and t1 equals t2.
    /// Recall that sets never contain duplicates.  If an attempt is made to add an element to a 
    /// set, and the element is already in the set, the set remains unchanged.
    /// 
    /// Given a DependencyGraph DG:
    /// 
    ///    (1) If s is a string, the set of all strings t such that (s,t) is in DG is called dependents(s).
    ///        (The set of things that depend on s)    
    ///        
    ///    (2) If s is a string, the set of all strings t such that (t,s) is in DG is called dependees(s).
    ///        (The set of things that s depends on) 
    //                           #dents,dees
    // For example, suppose DG = {("a", "b"), ("a", "c"), ("b", "d"), ("d", "d")}
    //     dependents("a") = {"b", "c"}
    //     dependents("b") = {"d"}
    //     dependents("c") = {}
    //     dependents("d") = {"d"}
    //     dependees("a") = {}
    //     dependees("b") = {"a"}
    //     dependees("c") = {"a"}
    //     dependees("d") = {"b", "d"}
    /// </summary>
    public class DependencyGraph
    {
        /// <summary>
        /// initilize the dependency graph named Dgraph by using Dictionary, 
        /// key type is string, value type is hashset.
        /// </summary>
        Dictionary<string, HashSet<string>> DGrapy = 
            new Dictionary<string, HashSet<string>>();

        /// <summary>
        /// initiallize the size.
        /// </summary>
        private int count = 0;


        /// <summary>
        /// Creates an empty DependencyGraph.
        /// </summary>
        public DependencyGraph()
        {
            DGrapy = new Dictionary<string, HashSet<string>>();
        }


        /// <summary>
        /// The number of ordered pairs in the DependencyGraph.
        /// </summary>
        public int Size
        {
            get { return count; }
        }


        /// <summary>
        /// The size of dependees(s).
        /// This property is an example of an indexer.  If dg is a DependencyGraph, you would
        /// invoke it like this:
        /// dg["a"]
        /// It should return the size of dependees("a")
        /// </summary>
        public int this[string s]
        {
            get
            {
                int deesSize = 0;
                //go through key value pairs in Dgraph. if the value of the pair
                //contains string s, integrate the dependees size
                foreach (KeyValuePair<string, HashSet<string>> pair in DGrapy)
                {
                    if (pair.Value.Contains(s))
                    {
                        deesSize++;
                    }
                }
                return deesSize;
            }
        }


        /// <summary>
        /// Reports whether dependents(s) is non-empty.
        /// </summary>
        public bool HasDependents(string s)
        {
            //go through keyvalue pairs in Dgraph
            foreach (KeyValuePair<string, HashSet<string>> kvp in DGrapy)
            {
                //return true if key=s and pair has value.
                if (kvp.Key == s && kvp.Value != null)
                {
                    return true;
                }
            }
            return false;
        }


        /// <summary>
        /// Reports whether dependees(s) is non-empty.
        /// </summary>
        public bool HasDependees(string s)
        {
            {
                //go through keyvalue pairs in Dgraph
                foreach (KeyValuePair<string, HashSet<string>> kvp in DGrapy)
                {
                    //return true if the value of pair contains s.
                    if (kvp.Value.Contains(s))
                    {
                        return true;
                    }
                }
                return false;
            }
        }


        /// <summary>
        /// Enumerates dependents(s).
        /// </summary>
        public IEnumerable<string> GetDependents(string s)
        {
            //build an empty linked list named dependents
            LinkedList<String> dependents = new LinkedList<string>();
            //if the graph has the dependents s
            if (HasDependents(s))
            {
                //for each string in hashset corresponding with key s
                foreach (string str in DGrapy[s])
                {
                    //addfirst the string to the dependents linkedlist
                    dependents.AddFirst(str);
                }
            }

            return dependents;
        }

        /// <summary>
        /// Enumerates dependees(s).
        /// </summary>
        public IEnumerable<string> GetDependees(string s)
        {
            //build an empty linked list named dependees
            LinkedList<String> dependees = new LinkedList<string>();
            //if the graph has the HasDependees s
            if (HasDependees(s))
            {
                //For each keyvaluepair in graph, go through every string 
                //in the value of the pair
                foreach (KeyValuePair<string, HashSet<string>> kvp in DGrapy)
                {
                    foreach (string str in kvp.Value)
                    {
                        // if the string is equal to the input string s and 
                        //the dependees linked list has not added the key yet
                        if (str == s && !dependees.Contains(kvp.Key))
                        {
                            //addfirst the key to the dependees linked list
                            dependees.AddFirst(kvp.Key);
                        }
                    }
                }
            }
            return dependees;
        }


        /// <summary>
        /// <para>Adds the ordered pair (s,t), if it doesn't exist</para>
        /// 
        /// <para>This should be thought of as:</para>   
        /// 
        ///   t depends on s
        ///
        /// </summary>
        /// <param name="s"> s must be evaluated first. T depends on S</param>
        /// <param name="t"> t cannot be evaluated until s is evaluated</param>
        public void AddDependency(string s, string t)
        {
            // if s and t are not null, go through the function
            if (s != null && t != null)
            {
                // check if the graph contains key s
                bool containKey = DGrapy.ContainsKey(s);
                // if the graph contains s, and does not contains v in value hashset, 
                // add t to the has set and increment the size of the graph by 1.
                if (containKey && !DGrapy[s].Contains(t))
                {
                    DGrapy[s].Add(t);
                    count++;
                }
                // if the graph contains s, and contains v in corespondinf value hashset, 
                // end the function
                else if (containKey && DGrapy[s].Contains(t))
                {
                    return;
                }
                // otherwise, creat a new hashset named new dee, add t to newdee, 
                // and add newdee hashset to the graph along with the key s
                else
                {
                    HashSet<string> newDee = new HashSet<string>();
                    newDee.Add(t);
                    DGrapy.Add(s, newDee);
                    count++;

                }
            }
        }


        /// <summary>
        /// Removes the ordered pair (s,t), if it exists
        /// </summary>
        /// <param name="s">s must be evaluated first. T depends on S</param>
        /// <param name="t">t cannot be evaluated until s is evaluated</param>
        public void RemoveDependency(string s, string t)
        {
            // if s and t are not null, go through the function
            if (s != null && t != null)
            {
                //check if the graph has dependents s
                bool hasDents = HasDependents(s);
                // it has and also has coresponding t
                if (hasDents && HasDependees(t))
                {
                    //get the count of dependents
                    int i = 0;
                    i = GetDependents(s).Count();
                    //if the count is equal to 1, remove the key s from the graph
                    if (i == 1)
                    {
                        DGrapy.Remove(s);
                        count--;
                    }
                    // otherwise just remove the t from value hashset
                    else
                    {
                        HashSet<string> dees = DGrapy[s];
                        dees.Remove(t);
                        count--;
                    }
                }
                //if does not have s, return
                else
                {
                    return;
                }
            }
        }


        /// <summary>
        /// Removes all existing ordered pairs of the form (s,r).  Then, for each
        /// t in newDependents, adds the ordered pair (s,t).
        /// </summary>
        public void ReplaceDependents(string s, IEnumerable<string> newDependents)
        {
            // if s is not a null, go through the function
            if (s != null)
            {
                // check is has dependents s
                bool hasDents = HasDependents(s);
                // if has, record the numbers of strings in the valueset 
                // cooresponds key s, and remove the pair
                if (hasDents)
                {
                    int i = 0;
                    foreach (string str in DGrapy[s])
                    {
                        i++;
                    }
                    DGrapy.Remove(s);
                    // after remove, decrement the size of the graph
                    count = count - i;

                    // for each string in newdependents, if the string is not null, 
                    // adddependency (s,str)
                    foreach (string str in newDependents)
                    {
                        if (str != null)
                            AddDependency(s, str);
                    }

                }
                //otherwise, just add each string t of new dependents with s to the graph
                else
                {
                    foreach (string t in newDependents)
                    {
                        AddDependency(s, t);
                    }
                }
            }
        }


        /// <summary>
        /// Removes all existing ordered pairs of the form (r,s).  Then, for each 
        /// t in newDependees, adds the ordered pair (t,s).
        /// </summary>
        public void ReplaceDependees(string s, IEnumerable<string> newDependees)
        {
            // if s is not a null, go through the function
            if (s != null)
            {
                // for each pair in the graph, if strings from the value hashset that 
                // contain s, remove the s from the set
                foreach (KeyValuePair<string, HashSet<string>> pair in DGrapy)
                {
                    if (pair.Value.Contains(s))
                    {
                        pair.Value.Remove(s);
                        count--;
                    }
                }
                // for each string see in newDpendees
                foreach (string dee in newDependees)
                {
                    // if the graph has alreading contained the key dee, add string s to 
                    // the coresponding value set and decrasing the size by 1
                    if (DGrapy.ContainsKey(dee))
                    {
                        DGrapy[dee].Add(s);
                        count--;
                    }
                    // otherwise adddependency directly, and decrese the size by 1.
                    else
                    {
                        AddDependency(dee, s);
                        count--;
                    }
                }
            }
        }
    }
}