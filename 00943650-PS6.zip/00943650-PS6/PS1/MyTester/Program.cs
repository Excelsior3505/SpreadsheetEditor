﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FormulaEvaluator;


namespace MyTester
{
    /// <summary>
    /// program class
    /// </summary>
    class Program
    {
        /// <summary>
        /// the main of the solution, crates a console application and displays output
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            //tested expressions

            //basics
            //string str = "1 1 33  1";
            //string str = "1+2";   
            //string str = "1+2-8";
            //string str = "1+402-40";
            //string str = "5*3";
            //string str = "5*12/3";
            //string str = "6+3*8/0";

            //from discussion
            //string str = "10 / (6 / 3) / 2"; 
            //string str = "()3";
            //string str = "-(3+2)";
            //string str = "(6+3)(1-4)";//

            // others
            //string str = "1-9/3";
            //string str = "1-9/3+8";
            //string str = "(1-9)/3+8";
            string str = "(1-((9/3)+8))";
            //string str = "2*((10/4)*9)";
            //string str = "1 + 45 () - ()5 * 12/(4+3-1)";
            //string str = "()(()("; //invalid
            //string str = "((())())"; //invalid
            //string str = "8()";
            //string str = "(8())";
            //string str = "6 +"; //invalid
            //string str = ""; //invalid
            //string str = "5*-6"; //invalid

            //for variable testing
            string str2 = "1 + Z6 - 4";
            //string str2 = "1 + z6 - 4";
            //string str2 = "1+z 6 -4";
            //string str2 = "1+6z-4";
            Console.WriteLine("The expression: " + str);
            Console.WriteLine("The output: "+Evaluator.Evaluate(str, NoVariableLookUp));
            Console.WriteLine("");

            Console.WriteLine("The expression: " + str2);
            Console.WriteLine("The output: "+Evaluator.Evaluate(str2, SimpleLookup));
            Console.ReadLine();
        }

        /// <summary>
        /// An function that returns 0 and no nessesary input string.
        /// </summary>
        /// <param name="v"></param>
        /// <returns></returns>
        public static int NoVariableLookUp(string v)
        {
            return 0;
        }

        /// <summary>
        /// An function that will be passed as delegate to the evaluator class with an string input as an variable.
        /// </summary>
        /// <param name="v">looking up variable.</param>
        /// <returns></returns>
        public static int SimpleLookup(string v)
        {
            // Do anything here. Decide whether or not this delegate has a value for v, and return its value, or throw if it doesn't.
            if (v == "Z6")
                return 20;
            else if (v == "z6")
                return 20;
            else { throw new ArgumentException("there is no value for the variable/wrong variable"); }
        }
    }
}
