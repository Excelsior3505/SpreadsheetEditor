﻿///-----------------------------------------------------------------
///   Namespace:      <Class Namespace> FormulaEvaluator
///   Class:          <Class Name> CS3500-001
///   Description:    <Description> Evaluator Class
///   Author:         <Author> Daniel, Sharon Xiao      Date: <DateTime> 9/4/2016
///   Notes:          <Notes> An class library of FormulaEvaluator, not an excuteable
///-----------------------------------------------------------------


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace FormulaEvaluator
{
    /// <summary>
    /// The Evaluator class under FormulaEvaluator namespace, which evaluate an expression.
    /// </summary>
    public class Evaluator
    {
        /// <summary>
        /// A delegate type that brings variables in which can be looked up in expression string.
        /// </summary>
        /// <param name="variable">Variable is a string type.</param>
        /// <returns>Returns an integer.</returns>
        public delegate int Lookup(String variable);


        /// <summary>
        /// The main method that evaluate an input string type expression and returns int type value.
        /// </summary>
        /// <param name="exp">String type parameter, stands for expression.</param>
        /// <param name="variableEvaluator">delegate type parameter that references ouside delegates.</param>
        /// <returns>Returns an integer type of the result of the expression</returns>
        public static int Evaluate(String exp, Lookup variableEvaluator)
        {
            //split the expression in to substring tokens.
            //remove all the space string.
            exp = Regex.Replace(exp, @"\s+", "");
            //tokenize all the components of the string.
            string[] tokens = Regex.Split(exp, "(\\()|(\\))|(-)|(\\+)|(\\*)|(/)");

            ////print the array of the tokens
            //foreach (string a in tokens)
            //{
            //    Console.Write(a + ",");
            //}

            //creat value stack and operator stack. count = 0.
            Stack<int> valueStack = new Stack<int>();
            Stack<string> opertorStack = new Stack<string>();

            //the loop for the calculation
            for (int i = 0; i < tokens.Length; i++)
            {
                //see if it's an integer
                var token = tokens[i];
                int? tryGetInt = IfInt(token);

                //I find out there might be "" empty strings appear when "(" and ")" are provided
                //therefore, jump to the next loop if there is "" empty string.
                if (token == "")
                    continue;

                //see if the begining token is a varible token
                //if the token is not an operator nor an integer, it is a variable
                //use the delegate to look up the variable and get the integer value and push it
                //to the valuestack.
                if (token != "+" && token != "-" &&
                     token != "*" && token != "/" &&
                     token != "(" && token != ")" && tryGetInt.HasValue == false)
                {
                    tryGetInt = variableEvaluator(token);
                    valueStack.Push(tryGetInt.Value);
                }

                // if the token has value, it is an integer, push to the valuestack
                else if (tryGetInt.HasValue)
                {
                    valueStack.Push(tryGetInt.Value);
                }

                // if the token is an open parenthesis, push to the operator stack
                else if (tokens[i] == "(")
                    opertorStack.Push(tokens[i]);

                // if the token is an close parenthesis, calculate the expression inside the parenthesis
                else if (tokens[i] == ")")
                {
                    while (opertorStack.Peek() != "(")
                        valueStack.Push(Calculate(opertorStack.Pop(), valueStack.Pop(), valueStack.Pop()));
                    opertorStack.Pop();
                }

                // if the token is any of the operator, push to the operator stack.
                else if (tokens[i] == "+" || tokens[i] == "-" || tokens[i] == "*" || tokens[i] == "/")
                {
                    while (opertorStack.Count != 0 && CalcOrder(tokens[i], opertorStack.Peek()))
                    {
                        if (valueStack.Count < 2)
                        {
                            throw new ArgumentException("conflict operators/not enough values");
                        }
                        valueStack.Push(Calculate(opertorStack.Pop(), valueStack.Pop(), valueStack.Pop()));
                    }
                    opertorStack.Push(tokens[i]);
                }

            }
            // while the count of operator stack is not 0, then calculate the top two values in the valuestack
            // with the operator.
            while (opertorStack.Count != 0)
            {

                if (opertorStack.Peek() == "(")
                    throw new ArgumentException("invalid expression");

                else if (valueStack.Count == 1 && opertorStack.Count == 1)
                {
                    throw new ArgumentException("unfinished expression");
                }
                else if (valueStack.Count == 1)
                {
                    return valueStack.Pop();
                }
                else if ((opertorStack.Peek() == "(" || opertorStack.Peek() == ")") && (valueStack.Count <= 2)&& opertorStack.Count<=1)
                    throw new ArgumentException("invalid expression");

                else if (valueStack.Count == 0)
                    throw new ArgumentException("invalid expression: no enough values.");


                valueStack.Push(Calculate(opertorStack.Pop(), valueStack.Pop(), valueStack.Pop()));
            }
            // return the final result
            if (valueStack.Count == 0)
            {
                throw new ArgumentException("no input values");
            }
            return valueStack.Pop();
        }

        /// <summary>
        /// A method to check if a string can be parsed or not, and returns the value it it can be parsed.
        /// </summary>
        /// <param name="token">A string that's passed in. </param>
        /// <returns></returns>
        public static int? IfInt(string token)
        {
            int output;
            if (Int32.TryParse(token, out output))
                return output;
            return null;
        }

        /// <summary>
        /// The method that can clearfy the precedence rules. 
        /// </summary>
        /// <param name="operator1"></param>
        /// <param name="operator2"></param>
        /// <returns></returns>
        public static Boolean CalcOrder(string operator1, string operator2)
        {
            if (operator2 == "(" || operator2 == ")")
                return false;
            else if ((operator1 == "*" || operator1 == "/") &&
                (operator2 == "+" || operator2 == "-"))
                return false;
            else
                return true;
        }

        /// <summary>
        /// The calculator that do the math with the order that's passed in.
        /// </summary>
        /// <param name="theOperator"></param>
        /// <param name="b">first value that's poped from value stack</param>
        /// <param name="a">second value that's poped from value stack</param>
        /// <returns>returns an integer result of calculation.</returns>
        public static int Calculate(string theOperator, int b, int a)
        {
            switch (theOperator)
            {
                case "+":
                    return a + b;
                case "-":
                    return a - b;
                case "*":
                    return a * b;
                case "/":
                    if (b == 0)
                        throw new DivideByZeroException("Cannot divided by 0");
                    return a / b;
            }
            return 0;
        }
    }
}
