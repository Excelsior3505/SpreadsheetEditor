﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestProject
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("test");
            Console.WriteLine("hahaha.");
            Console.WriteLine("how about now");

            Console.WriteLine("pull tested. testing push");
            Console.WriteLine("see if pushed");
            Console.WriteLine("one more time");
            
            Console.WriteLine("try pulling");
            Console.WriteLine("push.");
            Console.WriteLine("test branch");

            Console.ReadLine();
        }
    }
}
